//spray can object literal

var sizeSlider;

function SprayCan() {
  this.name = "sprayCanTool",
    this.icon = "assets/sprayCan.jpg",
    this.draw = function() {
      if (mouseIsPressed) {
          var spraySize = sizeSlider.value()
        for (var i = 0; i < spraySize; i++) {
          point(random(mouseX - spraySize , mouseX + spraySize),
            random(mouseY - spraySize, mouseY + spraySize));
        }
      }
    }
  this.populateOptions = function() {
       //Create a slider that will appear when the users clicks the Icon
        sizeSlider = createSlider(5,50,10);  
        sizeSlider.parent(select(".options"));
    };
    
     this.unselectTool = function(){
        select(".options").html("");
    }
};
