function scissorTool() {

  this.icon = "assets/scissors.png";
  this.name = "scissor";

  var selectMode = 1;
  var selectedArea = {
    x: 0,
    y: 0,
    w: 0,
    h: 0
  };

  var previousMouseX = -1;
  var previousMouseY = -1;

  var selectedPixels;

  this.draw = function() {

  }

  this.mousePressed = function() {

    //press in the canvas
    if (mouseY <= getTheCanvasHeight()) {
      if (selectMode == 1) //select area mode
      {
        if (previousMouseX == -1) {
          previousMouseX = mouseX;
          previousMouseY = mouseY;
          selectedArea = {
            x: mouseX,
            y: mouseY,
            w: 0,
            h: 0
          };
        }
      } else if (selectMode == 2) //paste mode
      {
        image(selectedPixels, mouseX, mouseY);
        loadPixels();
      }
    }
  }

  this.mouseDragged = function() {

    //if out of canvas dont do anything
    if (mouseY >= getTheCanvasHeight()) {
      return;
    }

    if (selectMode == 1) //select area mode
    {
      updatePixels();

      var w = mouseX - selectedArea.x;
      var h = mouseY - selectedArea.y;

      selectedArea.w = w;
      selectedArea.h = h;
      noStroke();
      fill(255, 0, 0, 50);
      rect(selectedArea.x, selectedArea.y, selectedArea.w, selectedArea.h);
    }
  }

  this.mouseReleased = function() {
    if (selectMode == 1) {
      showScissorButton();
    } else if (selectMode == 2) {
      previousMouseX = -1;
      previousMouseY = -1;
    }
  }


  this.unselectTool = function() {
    //when the tool is deselected update the pixels to just show the drawing and
    //hide the line of symmetry.
    updatePixels();
    //clear options
    select(".options").html("");

    //set back the default fill and stroke colour
    fill(colourP.selectedColour);
    stroke(colourP.selectedColour);

    //reset to the starting
    selectedArea = {
      x: 0,
      y: 0,
      w: 0,
      h: 0
    };
    previousMouseX = -1;
    selectMode = 1;
    previousMouseX = -1;
    previousMouseY = -1;
    selectedPixels = null;
  };

  function scissorButtonClicked() {
    // When the scissor button is clicked
    if (selectMode == 1) {
      selectMode = 2;
      //show button
      showScissorButton();
      //lable button to End Paste
      select("#scissorButton").html("End Paste");
      cutButtonClicked();
    } else if (selectMode == 2) {
      selectMode = 1;
      //hide button
      hideScissorButton();
      //label button to Cut
      select("#scissorButton").html("Cut");
      pasteButtonClicked();
      previousMouseX = -1;
    }
  }

  function cutButtonClicked() {
    updatePixels();
    //store the pixels
    selectedPixels = get(selectedArea.x, selectedArea.y, selectedArea.w, selectedArea.h);

    //to draw a rectangle over the portion to be cut
    fill(255);
    noStroke();
    rect(selectedArea.x, selectedArea.y, selectedArea.w, selectedArea.h);
    loadPixels();
  }


  function getTheCanvasHeight() {
    var canvasContainer = select('#content');
    var drawingCanvasHeight = canvasContainer.size().height;
    return drawingCanvasHeight;
  }

  function pasteButtonClicked() {
    loadPixels();
  }

  function showScissorButton() {
      //show the button
    var cutButton = document.getElementById("scissorButton");
    cutButton.style.visibility = "visible";
  }

  function hideScissorButton() {
      //hide the button
    var cutButton = document.getElementById("scissorButton");
    cutButton.style.visibility = "hidden";
  }

  this.populateOptions = function() {
       //Will appear when the users clicks the Icon
    select(".options").html("<button style='visibility:hidden' id='scissorButton'>Cut</button>");
    select("#scissorButton").mouseClicked(scissorButtonClicked);
  }
}
