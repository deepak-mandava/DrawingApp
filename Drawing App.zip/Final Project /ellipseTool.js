function EllipseTool() {
  this.icon = "assets/ellipse.jpg";
  this.name = "ellipse";

  var previousMouseX = -1;
  var previousMouseY = -1;
  var firstMouseX = -1;
  var firstMouseY = -1;
  var check;

  this.setup = function() {
    check = createSelect();
    check.option('fill');
    check.option('unfill');
    check.selected('fill');
  }

  this.draw = function() {
    if (mouseIsPressed) {
      if (previousMouseX == -1) {
        previousMouseX = mouseX;
        previousMouseY = mouseY;
        firstMouseX = mouseX;
        firstMouseY = mouseY;
      } else {
        updatePixels();
          
          //Gives the user ability to choose fill or unfilled ellipses
        if (check.value() == "unfill") {
          noFill();
        } else {
          fill(colourP.selectedColour);
        }

        var rLength = (mouseX - firstMouseX);
        var rWidth = (mouseY - firstMouseY);
        ellipse(firstMouseX, firstMouseY, rLength, rWidth);
        previousMouseX = mouseX;
        previousMouseY = mouseY;
      }
    } else {
      previousMouseX = -1;
      previousMouseY = -1;
      loadPixels();
    }
  }

  this.populateOptions = function() {
    //appear when the users clicks the Icon
    check.parent(select(".options"));
  }
  this.unselectTool = function() {
    select(".options").html("");
  }
}
