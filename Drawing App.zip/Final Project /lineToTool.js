function LineToTool() {
  this.icon = "assets/lineTo.jpg";
  this.name = "LineTo";

  var startMouseX = -1;
  var startMouseY = -1;
  var drawing = false;

  var ltSlider;

  this.draw = function() {

    // code for drawing lines
    if (mouseIsPressed) {
      if (startMouseX == -1) {
        startMouseX = mouseX;
        startMouseY = mouseY;
        drawing = true;
        loadPixels();
      } else {
        updatePixels();
        stroke(colourP.selectedColour);
        var size = ltSlider.value();
        strokeWeight(size);
        line(startMouseX, startMouseY, mouseX, mouseY);
      }

    } else if (drawing) {
      drawing = false;
      startMouseX = -1;
      startMouseY = -1;
    }
  };

  this.populateOptions = function() {
      //Create a slider that will appear when the users clicks the Icon
    ltSlider = createSlider(2, 20, 4);
    ltSlider.parent(select(".options"));
  };

  this.unselectTool = function() {
    select(".options").html("");
  };
}
