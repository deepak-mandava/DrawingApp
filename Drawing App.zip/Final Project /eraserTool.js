function eraserTool() {
  //set an icon and a name for the object
  this.icon = "assets/eraser.png";
  this.name = "eraser";

  var eraserSlider;

  this.draw = function() {

  };
  this.mouseDragged = function() {
      //when the user drags the mouse, eraser function takes place
    var eraserSize = eraserSlider.value();
    fill(255);
    noStroke();
    ellipse(mouseX - eraserSize / 2, mouseY - eraserSize / 2, eraserSize, eraserSize);
  };

  this.populateOptions = function() {
      //Create a slider that will appear when the users clicks the Icon
    eraserSlider = createSlider(5, 60, 15);
    eraserSlider.parent(select(".options"));
  };

  this.unselectTool = function() {
    select(".options").html("");
  }
}
