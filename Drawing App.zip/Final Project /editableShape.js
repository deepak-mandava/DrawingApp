function editableShape() {
  //set an icon and a name for the object
  this.icon = "assets/shape.png";
  this.name = "editableShape";

  var editButton;
  var finishButton;
  var editMode = false;
  var currentShape = [];

  this.draw = function() {
    updatePixels();

    if (mousePressIsOnCanvas(canvas) && mouseIsPressed) {

      if (!editMode) {
        currentShape.push({
          x: mouseX,
          y: mouseY
        })
      } else {
        for (var i = 0; i < currentShape.length; i++) {
          if (dist(currentShape[i].x,
              currentShape[i].y,
              mouseX,
              mouseY) < 15) {
            currentShape[i].x = mouseX;
            currentShape[i].y = mouseY;
          }
        }
      }
    }

    noFill();
    beginShape();

    for (var i = 0; i < currentShape.length; i++) {
      vertex(currentShape[i].x, currentShape[i].y);

      if (editMode) {
        fill("red");
        ellipse(currentShape[i].x, currentShape[i].y, 10);
        noFill();
      }
    }
    endShape();

  }

  this.populateOptions = function() {
    //appear when the users clicks the Icon

    editMode = false;
    currentShape = [];

    loadPixels();
    select(".options").html("<button style='visibility:hidden' id='editButton1'>Edit Shape</button><button style='visibility:hidden' id='editButton2'>Complete Shape</button>");

    select("#editButton1").mouseClicked(editButtonIsPressed);
    select("#editButton2").mouseClicked(finishButtonIsPressed);
  }
  this.unselectTool = function() {
    select(".options").html("");
  }

  function editButtonIsPressed() {

    if (editMode) {
      editMode = false;
      select("#editButton1").html("Edit Shape")
    } else {
      editMode = true;
      select("#editButton1").html("Add Vertices");
    }
  }

  function finishButtonIsPressed() {

    editMode = false;
    draw();
    loadPixels();
    currentShape = [];
    hideEditButton();
    select("#editButton1").html("Edit Shape");
  }

  function mousePressIsOnCanvas(canvas) {
    //check whether the mouse is being pressed on the canvas

    if (mouseX > canvas.elt.offsetLeft &&
      mouseX < (canvas.elt.offsetLeft + canvas.width + canvas.width) &&
      mouseY > canvas.elt.offsetTop &&
      mouseY < (canvas.elt.offsetTop + canvas.height)) {
      return true;
    }
    return false;
  }

  this.mouseReleased = function() {
    // When the mouse is released show the edit button
    showEditButton();
  }

  function showEditButton() {
    // This is to show the edit button on canvas
    var editButton1 = document.getElementById("editButton1");
    editButton1.style.visibility = "visible";
    var editButton2 = document.getElementById("editButton2");
    editButton2.style.visibility = "visible";
  }

  function hideEditButton() {
    // This is to hide the edit button on canvas
    var editButton1 = document.getElementById("editButton1");
    editButton1.style.visibility = "hidden";
    var editButton2 = document.getElementById("editButton2");
    editButton2.style.visibility = "hidden";
  }

}
